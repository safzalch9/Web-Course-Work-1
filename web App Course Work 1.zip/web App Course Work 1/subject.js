let subjects = [{

        lesson: "English Language",
        location: 'Burj Khalifa',
        price: "500",
        spaces: 5,
        image: "img/englishlanguage.jpg"
    },
    {
        lesson: "Swimming",
        location: 'Burj Al Arab',
        price: "3000",
        spaces: 5,
        image: "img/swimming.jpg"
    },
    {
        lesson: "Sports activity",
        location: 'Global Village',
        price: "4000",
        spaces: 5,
        image: "img/sportactivity.png"
    },
    {
        lesson: "Ice skating",
        location: 'Dubai Mall',
        price: "1500",
        spaces: 5,
        image: "img/icekating.png"
    },
    {
        lesson: "Futsal",
        location: 'Ski Dubai',
        price: "2000",
        spaces: 5,
        image: "img/futsall.png"
    },
    {
        lesson: "Arabic",
        location: 'Dubai Garden',
        price: "3000",
        spaces: 5,
        image: "img/arabic.jpeg"
    },
    {
        lesson: "Indoor Games",
        location: 'Down Town',
        price: "1000",
        spaces: 5,
        image: "img/indoorgames.jpg"
    },
    {
        lesson: "Outdoor Games",
        location: 'Desert Safari',
        price: "800",
        spaces: 5,
        image: "img/ouutdoorgames.png"
    },
    {
        lesson: "Movies",
        location: 'Dubai Mall',
        price: "500",
        spaces: 5,
        image: "img/movies.jpg"

    },
    {
        lesson: "Practice a Skill",
        location: 'Home town',
        price: "200",
        spaces: 5,
        image: "img/practiceskils.png"

    },
]